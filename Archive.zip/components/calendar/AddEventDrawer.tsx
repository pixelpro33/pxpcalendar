"use client";

import { DraftState, EventType, RepeatType } from "./types";
import { TYPE_CONFIG } from "./utils";

type Props = {
  isOpen: boolean;
  draft: DraftState;
  onClose: () => void;
  onSave: () => void;
  onChange: (patch: Partial<DraftState>) => void;
  onOpenRepeatModal: () => void;
  onOpenColorModal: () => void;
};

function SectionTitle({ children }: { children: React.ReactNode }) {
  return (
    <div
      style={{
        fontSize: 12,
        textTransform: "uppercase",
        letterSpacing: 1.1,
        opacity: 0.55,
        marginBottom: 8,
      }}
    >
      {children}
    </div>
  );
}

export default function AddEventDrawer({
  isOpen,
  draft,
  onClose,
  onSave,
  onChange,
  onOpenRepeatModal,
  onOpenColorModal,
}: Props) {
  if (!isOpen) return null;

  return (
    <div
      onClick={onClose}
      style={{
        position: "fixed",
        inset: 0,
        background: "rgba(0,0,0,0.58)",
        backdropFilter: "blur(12px)",
        display: "flex",
        alignItems: "flex-end",
        justifyContent: "center",
        zIndex: 50,
      }}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        style={{
          width: "100%",
          maxWidth: 1040,
          maxHeight: "96vh",
          overflowY: "auto",
          background: "#111218",
          borderTopLeftRadius: 28,
          borderTopRightRadius: 28,
          border: "1px solid rgba(255,255,255,0.08)",
          boxShadow: "0 -20px 60px rgba(0,0,0,0.45)",
          animation: "slideUpDrawer 180ms ease-out",
        }}
      >
        <style>{`
          @keyframes slideUpDrawer {
            from { transform: translateY(28px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
          }
        `}</style>

        <div
          style={{
            position: "sticky",
            top: 0,
            background: "#111218",
            borderBottom: "1px solid rgba(255,255,255,0.06)",
            padding: "14px 16px 12px",
            zIndex: 2,
          }}
        >
          <div
            style={{
              width: 46,
              height: 5,
              borderRadius: 999,
              background: "rgba(255,255,255,0.18)",
              margin: "0 auto 12px",
            }}
          />

          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              gap: 12,
              alignItems: "center",
            }}
          >
            <button
              onClick={onClose}
              style={{
                border: "none",
                background: "transparent",
                color: "#93c5fd",
                fontSize: 16,
                cursor: "pointer",
              }}
            >
              Cancel
            </button>

            <div style={{ fontWeight: 700, fontSize: 18 }}>New item</div>

            <button
              onClick={onSave}
              style={{
                border: "none",
                background: "transparent",
                color: "#93c5fd",
                fontSize: 16,
                cursor: "pointer",
                fontWeight: 700,
              }}
            >
              Save
            </button>
          </div>
        </div>

        <div style={{ padding: 18, display: "grid", gap: 16 }}>
          <input
            value={draft.title}
            onChange={(e) => onChange({ title: e.target.value })}
            placeholder="Add title"
            style={{
              width: "100%",
              background: "transparent",
              border: "none",
              color: "white",
              fontSize: 42,
              lineHeight: 1.06,
              outline: "none",
            }}
          />

          <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
            {(Object.keys(TYPE_CONFIG) as EventType[]).map((type) => {
              const cfg = TYPE_CONFIG[type];
              const active = draft.type === type;

              return (
                <button
                  key={type}
                  onClick={() => onChange({ type })}
                  style={{
                    border: `1px solid ${
                      active ? cfg.border : "rgba(255,255,255,0.12)"
                    }`,
                    background: active ? cfg.bg : "rgba(255,255,255,0.04)",
                    color: active ? cfg.color : "white",
                    borderRadius: 14,
                    padding: "10px 14px",
                    cursor: "pointer",
                    fontWeight: 600,
                  }}
                >
                  {cfg.label}
                </button>
              );
            })}
          </div>

          <div
            style={{
              display: "grid",
              gap: 14,
              gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))",
            }}
          >
            <div
              style={{
                background: "rgba(255,255,255,0.04)",
                border: "1px solid rgba(255,255,255,0.07)",
                borderRadius: 18,
                padding: 16,
              }}
            >
              <SectionTitle>Details</SectionTitle>
              <textarea
                value={draft.details}
                onChange={(e) => onChange({ details: e.target.value })}
                placeholder="Add details"
                rows={4}
                style={{
                  width: "100%",
                  resize: "vertical",
                  background: "transparent",
                  border: "none",
                  outline: "none",
                  color: "white",
                  fontSize: 16,
                  fontFamily: "inherit",
                }}
              />
            </div>

            <div
              style={{
                background: "rgba(255,255,255,0.04)",
                border: "1px solid rgba(255,255,255,0.07)",
                borderRadius: 18,
                padding: 16,
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                gap: 12,
              }}
            >
              <div>
                <div style={{ fontWeight: 650, marginBottom: 4 }}>All day</div>
                <div style={{ opacity: 0.6, fontSize: 14 }}>
                  Daca e o zi intreaga, fara ora fixa
                </div>
              </div>

              <button
                onClick={() => onChange({ allDay: !draft.allDay })}
                style={{
                  width: 66,
                  height: 36,
                  borderRadius: 999,
                  border: "none",
                  background: draft.allDay ? "#2563eb" : "rgba(255,255,255,0.12)",
                  position: "relative",
                  cursor: "pointer",
                  flexShrink: 0,
                }}
              >
                <span
                  style={{
                    position: "absolute",
                    top: 4,
                    left: draft.allDay ? 34 : 4,
                    width: 28,
                    height: 28,
                    borderRadius: "50%",
                    background: "white",
                    transition: "all 0.18s ease",
                  }}
                />
              </button>
            </div>

            <div
              style={{
                background: "rgba(255,255,255,0.04)",
                border: "1px solid rgba(255,255,255,0.07)",
                borderRadius: 18,
                padding: 16,
              }}
            >
              <SectionTitle>Date & time</SectionTitle>

              <div
                style={{
                  display: "grid",
                  gridTemplateColumns: draft.allDay ? "1fr" : "1fr 1fr",
                  gap: 10,
                }}
              >
                <input
                  type="date"
                  value={draft.date}
                  onChange={(e) => onChange({ date: e.target.value })}
                  style={{
                    width: "100%",
                    background: "rgba(255,255,255,0.04)",
                    border: "1px solid rgba(255,255,255,0.08)",
                    borderRadius: 14,
                    color: "white",
                    padding: 14,
                    fontSize: 15,
                    outline: "none",
                  }}
                />

                {!draft.allDay && (
                  <input
                    type="time"
                    value={draft.time}
                    onChange={(e) => onChange({ time: e.target.value })}
                    style={{
                      width: "100%",
                      background: "rgba(255,255,255,0.04)",
                      border: "1px solid rgba(255,255,255,0.08)",
                      borderRadius: 14,
                      color: "white",
                      padding: 14,
                      fontSize: 15,
                      outline: "none",
                    }}
                  />
                )}
              </div>
            </div>

            <div
              style={{
                background: "rgba(255,255,255,0.04)",
                border: "1px solid rgba(255,255,255,0.07)",
                borderRadius: 18,
                padding: 16,
              }}
            >
              <SectionTitle>Repeat</SectionTitle>

              <button
                onClick={() =>
                  draft.repeat.value === "custom"
                    ? onOpenRepeatModal()
                    : onChange({
                        repeat: {
                          ...draft.repeat,
                          value: "custom",
                        },
                      })
                }
                style={{
                  width: "100%",
                  background: "rgba(255,255,255,0.04)",
                  border: "1px solid rgba(255,255,255,0.08)",
                  borderRadius: 14,
                  color: "white",
                  padding: 14,
                  fontSize: 15,
                  outline: "none",
                  cursor: "pointer",
                  textAlign: "left",
                }}
              >
                {draft.repeat.label}
              </button>

              <div
                style={{
                  marginTop: 10,
                  display: "grid",
                  gridTemplateColumns: "repeat(auto-fit, minmax(120px, 1fr))",
                  gap: 8,
                }}
              >
                {[
                  { value: "none", label: "Does not repeat" },
                  { value: "daily", label: "Every day" },
                  { value: "weekly", label: "Every week" },
                  { value: "monthly", label: "Every month" },
                  { value: "yearly", label: "Every year" },
                  { value: "custom", label: "Custom" },
                ].map((option) => {
                  const active = draft.repeat.value === option.value;

                  return (
                    <button
                      key={option.value}
                      onClick={() => {
                        if (option.value === "custom") {
                          onOpenRepeatModal();
                          return;
                        }

                        onChange({
                          repeat: {
                            value: option.value as RepeatType,
                            label: option.label,
                          },
                        });
                      }}
                      style={{
                        border: `1px solid ${
                          active ? "rgba(96,165,250,0.45)" : "rgba(255,255,255,0.08)"
                        }`,
                        background: active
                          ? "rgba(59,130,246,0.22)"
                          : "rgba(255,255,255,0.03)",
                        color: "white",
                        borderRadius: 12,
                        padding: "11px 12px",
                        cursor: "pointer",
                        textAlign: "left",
                        minHeight: 48,
                      }}
                    >
                      {option.label}
                    </button>
                  );
                })}
              </div>
            </div>

            {(draft.type === "pay" || draft.type === "event") && (
              <div
                style={{
                  background: "rgba(255,255,255,0.04)",
                  border: "1px solid rgba(255,255,255,0.07)",
                  borderRadius: 18,
                  padding: 16,
                }}
              >
                <SectionTitle>Suma (lei)</SectionTitle>
                <input
                  type="number"
                  value={draft.amount}
                  onChange={(e) => onChange({ amount: e.target.value })}
                  placeholder="Ex: 220"
                  style={{
                    width: "100%",
                    background: "rgba(255,255,255,0.04)",
                    border: "1px solid rgba(255,255,255,0.08)",
                    borderRadius: 14,
                    color: "white",
                    padding: 14,
                    fontSize: 15,
                    outline: "none",
                  }}
                />
              </div>
            )}

            <div
              style={{
                background: "rgba(255,255,255,0.04)",
                border: "1px solid rgba(255,255,255,0.07)",
                borderRadius: 18,
                padding: 16,
              }}
            >
              <SectionTitle>Adresa</SectionTitle>
              <input
                value={draft.address}
                onChange={(e) => onChange({ address: e.target.value })}
                placeholder="Optional"
                style={{
                  width: "100%",
                  background: "rgba(255,255,255,0.04)",
                  border: "1px solid rgba(255,255,255,0.08)",
                  borderRadius: 14,
                  color: "white",
                  padding: 14,
                  fontSize: 15,
                  outline: "none",
                }}
              />
            </div>

            <div
              style={{
                background: "rgba(255,255,255,0.04)",
                border: "1px solid rgba(255,255,255,0.07)",
                borderRadius: 18,
                padding: 16,
              }}
            >
              <SectionTitle>Custom color</SectionTitle>

              <button
                onClick={onOpenColorModal}
                style={{
                  width: "100%",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "space-between",
                  gap: 12,
                  background: "rgba(255,255,255,0.04)",
                  border: "1px solid rgba(255,255,255,0.08)",
                  borderRadius: 14,
                  color: "white",
                  padding: 14,
                  fontSize: 15,
                  outline: "none",
                  cursor: "pointer",
                }}
              >
                <span>{draft.customColor || "Pick color"}</span>
                <span
                  style={{
                    width: 24,
                    height: 24,
                    borderRadius: "50%",
                    background: draft.customColor || "rgba(255,255,255,0.18)",
                    border: "1px solid rgba(255,255,255,0.12)",
                    flexShrink: 0,
                  }}
                />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}