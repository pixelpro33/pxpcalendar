"use client";

type Props = {
  paid: number;
  remaining: number;
};

export default function CalendarStats({ paid, remaining }: Props) {
  return (
    <div
      style={{
        display: "grid",
        gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))",
        gap: 14,
        marginBottom: 16,
      }}
    >
      <div
        style={{
          background: "rgba(255,255,255,0.05)",
          border: "1px solid rgba(255,255,255,0.08)",
          borderRadius: 20,
          padding: 16,
          boxShadow: "0 10px 28px rgba(0,0,0,0.16)",
        }}
      >
        <div
          style={{
            fontSize: 13,
            textTransform: "uppercase",
            letterSpacing: 1.2,
            opacity: 0.55,
            marginBottom: 8,
          }}
        >
          Plătit deja
        </div>
        <div style={{ fontSize: 30, fontWeight: 700 }}>{paid} lei</div>
      </div>

      <div
        style={{
          background: "rgba(255,255,255,0.05)",
          border: "1px solid rgba(255,255,255,0.08)",
          borderRadius: 20,
          padding: 16,
          boxShadow: "0 10px 28px rgba(0,0,0,0.16)",
        }}
      >
        <div
          style={{
            fontSize: 13,
            textTransform: "uppercase",
            letterSpacing: 1.2,
            opacity: 0.55,
            marginBottom: 8,
          }}
        >
          Mai ai de plătit
        </div>
        <div style={{ fontSize: 30, fontWeight: 700 }}>{remaining} lei</div>
      </div>
    </div>
  );
}