"use client";

import { CalendarItem } from "./types";
import { getDaysRemainingLabel, getEventChipStyle, TYPE_CONFIG } from "./utils";

type Props = {
  item: CalendarItem;
  onClick: () => void;
  compact?: boolean;
};

export default function EventChip({ item, onClick, compact = false }: Props) {
  const typeCfg = TYPE_CONFIG[item.type];
  const style = getEventChipStyle(item);
  const daysRemaining = getDaysRemainingLabel(item.date);

  return (
    <button
      onClick={onClick}
      style={{
        ...style,
        width: "100%",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        gap: 10,
        borderRadius: 12,
        padding: compact ? "6px 8px" : "10px 12px",
        fontSize: compact ? 11 : 13,
        lineHeight: 1.25,
        cursor: "pointer",
        overflow: "hidden",
        whiteSpace: "nowrap",
        textOverflow: "ellipsis",
        backgroundClip: "padding-box",
        minHeight: compact ? 32 : 48,
      }}
    >
      <div
        style={{
          display: "flex",
          alignItems: "center",
          gap: 8,
          minWidth: 0,
          flex: 1,
        }}
      >
        <span style={{ flexShrink: 0 }}>{typeCfg.icon}</span>

        {!item.allDay && item.time && (
          <span style={{ opacity: 0.85, flexShrink: 0 }}>{item.time}</span>
        )}

        {item.allDay && (
          <span style={{ opacity: 0.6, flexShrink: 0 }}>all-day</span>
        )}

        <span
          style={{
            overflow: "hidden",
            textOverflow: "ellipsis",
            whiteSpace: "nowrap",
            textAlign: "left",
          }}
        >
          {item.title}
        </span>
      </div>

      {!compact && (
        <span
          style={{
            flexShrink: 0,
            opacity: 0.7,
            fontSize: 11,
          }}
        >
          {daysRemaining}
        </span>
      )}
    </button>
  );
}