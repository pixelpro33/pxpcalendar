export type EventType = "task" | "event" | "pay" | "birthday";

export type ViewMode = "grid" | "list";

export type RepeatType =
  | "none"
  | "daily"
  | "weekly"
  | "monthly"
  | "yearly"
  | "custom";

export type RepeatCustomUnit = "day" | "week" | "month" | "year";

export type PendingReminderMode =
  | "daily"
  | "with_next_scheduled"
  | "daily_and_next";

export type CalendarItem = {
  id: string;
  title: string;
  details?: string;
  type: EventType;
  date: string; // YYYY-MM-DD
  time?: string; // HH:mm
  allDay: boolean;
  completed: boolean;
  repeat: RepeatType;
  repeatCustomInterval?: number;
  repeatCustomUnit?: RepeatCustomUnit;
  amount?: number;
  actualPaidAmount?: number;
  customColor?: string;
  address?: string;
  pendingReminderMode?: PendingReminderMode;
};

export type TypeConfig = {
  label: string;
  color: string;
  bg: string;
  border: string;
  icon: string;
};