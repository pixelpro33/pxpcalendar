"use client";

import { DEFAULT_COLORS } from "./utils";

type Props = {
  isOpen: boolean;
  value: string;
  onClose: () => void;
  onSave: (value: string) => void;
};

export default function ColorPickerModal({ isOpen, value, onClose, onSave }: Props) {
  if (!isOpen) return null;

  return (
    <div
      onClick={onClose}
      style={{
        position: "fixed",
        inset: 0,
        background: "rgba(0,0,0,0.58)",
        backdropFilter: "blur(10px)",
        display: "flex",
        alignItems: "flex-end",
        justifyContent: "center",
        zIndex: 60,
      }}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        style={{
          width: "100%",
          maxWidth: 760,
          background: "#111218",
          borderTopLeftRadius: 28,
          borderTopRightRadius: 28,
          border: "1px solid rgba(255,255,255,0.08)",
          boxShadow: "0 -20px 60px rgba(0,0,0,0.45)",
          animation: "slideUpColor 180ms ease-out",
        }}
      >
        <style>{`
          @keyframes slideUpColor {
            from { transform: translateY(24px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
          }
        `}</style>

        <div
          style={{
            padding: "16px 18px 14px",
            borderBottom: "1px solid rgba(255,255,255,0.06)",
            display: "flex",
            justifyContent: "space-between",
            gap: 10,
            alignItems: "center",
          }}
        >
          <div style={{ fontSize: 22, fontWeight: 700 }}>Custom color</div>
          <button
            onClick={onClose}
            style={{
              border: "none",
              background: "rgba(255,255,255,0.06)",
              color: "white",
              borderRadius: 12,
              padding: "10px 12px",
              cursor: "pointer",
            }}
          >
            ✕
          </button>
        </div>

        <div style={{ padding: 18, display: "grid", gap: 16 }}>
          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(auto-fit, minmax(56px, 1fr))",
              gap: 12,
            }}
          >
            {DEFAULT_COLORS.map((color) => {
              const active = value === color;

              return (
                <button
                  key={color}
                  onClick={() => onSave(color)}
                  style={{
                    height: 56,
                    borderRadius: 16,
                    border: active
                      ? "2px solid rgba(255,255,255,0.9)"
                      : "1px solid rgba(255,255,255,0.08)",
                    background: color,
                    cursor: "pointer",
                  }}
                />
              );
            })}
          </div>

          <div
            style={{
              background: "rgba(255,255,255,0.04)",
              border: "1px solid rgba(255,255,255,0.08)",
              borderRadius: 18,
              padding: 16,
            }}
          >
            <div style={{ opacity: 0.55, marginBottom: 8, fontSize: 12, letterSpacing: 1 }}>
              HSL / HEX / RGBA
            </div>

            <input
              value={value}
              onChange={(e) => onSave(e.target.value)}
              placeholder="Ex: hsl(210 90% 60% / 0.26)"
              style={{
                width: "100%",
                background: "rgba(255,255,255,0.04)",
                border: "1px solid rgba(255,255,255,0.08)",
                borderRadius: 14,
                color: "white",
                padding: 14,
                fontSize: 15,
                outline: "none",
              }}
            />
          </div>

          <div
            style={{
              background: "rgba(255,255,255,0.04)",
              border: "1px solid rgba(255,255,255,0.08)",
              borderRadius: 18,
              padding: 16,
            }}
          >
            <div style={{ opacity: 0.55, marginBottom: 8, fontSize: 12, letterSpacing: 1 }}>
              PREVIEW
            </div>
            <div
              style={{
                width: "100%",
                height: 72,
                borderRadius: 18,
                background: value || "rgba(255,255,255,0.06)",
                border: "1px solid rgba(255,255,255,0.08)",
              }}
            />
          </div>

          <button
            onClick={onClose}
            style={{
              border: "none",
              borderRadius: 14,
              padding: "14px 16px",
              background: "#2563eb",
              color: "white",
              fontWeight: 700,
              cursor: "pointer",
            }}
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
}