"use client";

import { CustomRepeatConfig, RepeatValue } from "./types";

type Props = {
  isOpen: boolean;
  value: CustomRepeatConfig;
  onClose: () => void;
  onSave: (value: CustomRepeatConfig) => void;
};

const UNIT_OPTIONS: { value: CustomRepeatConfig["unit"]; label: string }[] = [
  { value: "day", label: "day" },
  { value: "week", label: "week" },
  { value: "month", label: "month" },
  { value: "year", label: "year" },
];

export default function RepeatModal({ isOpen, value, onClose, onSave }: Props) {
  if (!isOpen) return null;

  const preview =
    value.unit === "month" && value.monthDay
      ? `Every ${value.interval} ${value.interval === 1 ? "month" : "months"} on day ${value.monthDay}`
      : `Every ${value.interval} ${value.interval === 1 ? value.unit : `${value.unit}s`}`;

  return (
    <div
      onClick={onClose}
      style={{
        position: "fixed",
        inset: 0,
        background: "rgba(0,0,0,0.58)",
        backdropFilter: "blur(10px)",
        display: "flex",
        alignItems: "flex-end",
        justifyContent: "center",
        zIndex: 60,
      }}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        style={{
          width: "100%",
          maxWidth: 760,
          background: "#111218",
          borderTopLeftRadius: 28,
          borderTopRightRadius: 28,
          border: "1px solid rgba(255,255,255,0.08)",
          boxShadow: "0 -20px 60px rgba(0,0,0,0.45)",
          animation: "slideUpRepeat 180ms ease-out",
        }}
      >
        <style>{`
          @keyframes slideUpRepeat {
            from { transform: translateY(24px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
          }
        `}</style>

        <div
          style={{
            padding: "16px 18px 14px",
            borderBottom: "1px solid rgba(255,255,255,0.06)",
            display: "flex",
            justifyContent: "space-between",
            gap: 10,
            alignItems: "center",
          }}
        >
          <div style={{ fontSize: 22, fontWeight: 700 }}>Custom repeat</div>
          <button
            onClick={onClose}
            style={{
              border: "none",
              background: "rgba(255,255,255,0.06)",
              color: "white",
              borderRadius: 12,
              padding: "10px 12px",
              cursor: "pointer",
            }}
          >
            ✕
          </button>
        </div>

        <div style={{ padding: 18, display: "grid", gap: 16 }}>
          <div
            style={{
              background: "rgba(255,255,255,0.04)",
              border: "1px solid rgba(255,255,255,0.08)",
              borderRadius: 18,
              padding: 16,
            }}
          >
            <div style={{ opacity: 0.55, marginBottom: 8, fontSize: 12, letterSpacing: 1 }}>
              INTERVAL
            </div>

            <div
              style={{
                display: "grid",
                gridTemplateColumns: "120px 1fr",
                gap: 12,
              }}
            >
              <input
                type="number"
                min={1}
                value={value.interval}
                onChange={(e) =>
                  onSave({
                    ...value,
                    interval: Math.max(1, Number(e.target.value || 1)),
                  })
                }
                style={{
                  width: "100%",
                  background: "rgba(255,255,255,0.04)",
                  border: "1px solid rgba(255,255,255,0.08)",
                  borderRadius: 14,
                  color: "white",
                  padding: 14,
                  fontSize: 16,
                  outline: "none",
                }}
              />

              <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 8 }}>
                {UNIT_OPTIONS.map((option) => {
                  const active = value.unit === option.value;

                  return (
                    <button
                      key={option.value}
                      onClick={() => onSave({ ...value, unit: option.value })}
                      style={{
                        border: `1px solid ${
                          active ? "rgba(96,165,250,0.45)" : "rgba(255,255,255,0.08)"
                        }`,
                        background: active ? "rgba(59,130,246,0.22)" : "rgba(255,255,255,0.03)",
                        color: "white",
                        borderRadius: 12,
                        padding: "12px 10px",
                        cursor: "pointer",
                        fontWeight: 600,
                      }}
                    >
                      {option.label}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {value.unit === "month" && (
            <div
              style={{
                background: "rgba(255,255,255,0.04)",
                border: "1px solid rgba(255,255,255,0.08)",
                borderRadius: 18,
                padding: 16,
              }}
            >
              <div style={{ opacity: 0.55, marginBottom: 8, fontSize: 12, letterSpacing: 1 }}>
                ON DAY OF MONTH
              </div>

              <input
                type="number"
                min={1}
                max={31}
                value={value.monthDay ?? 1}
                onChange={(e) =>
                  onSave({
                    ...value,
                    monthDay: Math.min(31, Math.max(1, Number(e.target.value || 1))),
                  })
                }
                style={{
                  width: "100%",
                  background: "rgba(255,255,255,0.04)",
                  border: "1px solid rgba(255,255,255,0.08)",
                  borderRadius: 14,
                  color: "white",
                  padding: 14,
                  fontSize: 16,
                  outline: "none",
                }}
              />
            </div>
          )}

          <div
            style={{
              background: "rgba(59,130,246,0.10)",
              border: "1px solid rgba(59,130,246,0.28)",
              borderRadius: 18,
              padding: 16,
            }}
          >
            <div style={{ opacity: 0.55, marginBottom: 8, fontSize: 12, letterSpacing: 1 }}>
              PREVIEW
            </div>
            <div style={{ fontSize: 16 }}>{preview}</div>
          </div>

          <button
            onClick={onClose}
            style={{
              border: "none",
              borderRadius: 14,
              padding: "14px 16px",
              background: "#2563eb",
              color: "white",
              fontWeight: 700,
              cursor: "pointer",
            }}
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
}