"use client";

import { TYPE_CONFIG } from "./mockData";
import { EventType } from "./types";

type Props = {
  activeFilters: Record<EventType, boolean>;
  toggleFilter: (type: EventType) => void;
  hideEmptyDays: boolean;
  setHideEmptyDays: (value: boolean) => void;
};

export default function CalendarFilters({
  activeFilters,
  toggleFilter,
  hideEmptyDays,
  setHideEmptyDays,
}: Props) {
  return (
    <div
      style={{
        display: "flex",
        gap: 10,
        flexWrap: "wrap",
        marginBottom: 16,
      }}
    >
      {(Object.keys(TYPE_CONFIG) as EventType[]).map((type) => {
        const cfg = TYPE_CONFIG[type];
        const active = activeFilters[type];

        return (
          <button
            key={type}
            onClick={() => toggleFilter(type)}
            style={{
              border: `1px solid ${active ? cfg.border : "rgba(255,255,255,0.08)"}`,
              background: active ? cfg.bg : "rgba(255,255,255,0.04)",
              color: active ? cfg.color : "rgba(255,255,255,0.7)",
              borderRadius: 999,
              padding: "9px 13px",
              cursor: "pointer",
              display: "inline-flex",
              gap: 8,
              alignItems: "center",
              fontWeight: 600,
              fontSize: 13,
            }}
          >
            <span>{cfg.icon}</span>
            <span>{cfg.label}</span>
          </button>
        );
      })}

      <button
        onClick={() => setHideEmptyDays(!hideEmptyDays)}
        style={{
          border: "1px solid rgba(255,255,255,0.08)",
          background: hideEmptyDays
            ? "rgba(255,255,255,0.12)"
            : "rgba(255,255,255,0.04)",
          color: "white",
          borderRadius: 999,
          padding: "9px 13px",
          cursor: "pointer",
          display: "inline-flex",
          gap: 8,
          alignItems: "center",
          fontWeight: 600,
          fontSize: 13,
        }}
      >
        <span>{hideEmptyDays ? "✓" : "○"}</span>
        <span>Hide empty days</span>
      </button>
    </div>
  );
}