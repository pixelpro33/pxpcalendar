"use client";

import { CalendarItem } from "./types";
import { formatShortDate, getMonthName } from "./utils";
import EventChip from "./EventChip";

type Props = {
  year: number;
  month: number;
  daysInMonth: number;
  groupedByDay: Map<number, CalendarItem[]>;
  hideEmptyDays: boolean;
  onSelectItem: (item: CalendarItem) => void;
};

export default function CalendarList({
  year,
  month,
  daysInMonth,
  groupedByDay,
  hideEmptyDays,
  onSelectItem,
}: Props) {
  return (
    <div style={{ display: "grid", gap: 12 }}>
      {Array.from({ length: daysInMonth }, (_, index) => {
        const day = index + 1;
        const dayItems = groupedByDay.get(day) || [];
        const dateIso = `${year}-${String(month + 1).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
        const label = `${String(day).padStart(2, "0")} ${getMonthName(month)} ${year}`;

        if (hideEmptyDays && dayItems.length === 0) {
          return null;
        }

        return (
          <div
            key={dateIso}
            style={{
              background: "rgba(255,255,255,0.045)",
              border: "1px solid rgba(255,255,255,0.08)",
              borderRadius: 22,
              padding: 16,
              boxShadow: "0 10px 30px rgba(0,0,0,0.16)",
            }}
          >
            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                gap: 10,
                alignItems: "center",
                marginBottom: 12,
                flexWrap: "wrap",
              }}
            >
              <div style={{ fontWeight: 700, fontSize: 18 }}>{label}</div>
              <div style={{ opacity: 0.5, fontSize: 13 }}>
                {dayItems.length} item{dayItems.length === 1 ? "" : "s"}
              </div>
            </div>

            {dayItems.length === 0 ? (
              <div style={{ opacity: 0.35, fontSize: 14 }}>Fara evenimente</div>
            ) : (
              <div style={{ display: "grid", gap: 8 }}>
                {dayItems.map((item) => (
                  <EventChip
                    key={item.id}
                    item={item}
                    onClick={() => onSelectItem(item)}
                  />
                ))}
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}