import { CalendarItem, EventType, TypeConfig } from "./types";
import { TYPE_CONFIG } from "./mockData";

export function pad(n: number) {
  return String(n).padStart(2, "0");
}

export function toDateString(year: number, monthIndex: number, day: number) {
  return `${year}-${pad(monthIndex + 1)}-${pad(day)}`;
}

export function getDaysInMonth(year: number, monthIndex: number) {
  return new Date(year, monthIndex + 1, 0).getDate();
}

export function formatDisplayDate(item: CalendarItem) {
  const date = new Date(`${item.date}T${item.allDay ? "00:00" : item.time || "00:00"}`);
  return new Intl.DateTimeFormat("ro-RO", {
    weekday: "long",
    day: "2-digit",
    month: "short",
    year: "numeric",
  }).format(date);
}

export function formatEventDateTime(item: CalendarItem) {
  const date = new Date(`${item.date}T${item.allDay ? "00:00" : item.time || "00:00"}`);

  if (item.allDay) {
    return new Intl.DateTimeFormat("ro-RO", {
      weekday: "long",
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
    }).format(date);
  }

  return new Intl.DateTimeFormat("ro-RO", {
    weekday: "long",
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  }).format(date);
}

export function getDaysRemaining(item: CalendarItem) {
  const now = new Date();
  const eventDate = new Date(`${item.date}T${item.allDay ? "00:00" : item.time || "00:00"}`);

  const nowStart = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
  const eventStart = new Date(
    eventDate.getFullYear(),
    eventDate.getMonth(),
    eventDate.getDate()
  ).getTime();

  const diffDays = Math.round((eventStart - nowStart) / (1000 * 60 * 60 * 24));

  if (diffDays === 0) return "azi";
  if (diffDays === 1) return "maine";
  if (diffDays > 1) return `in ${diffDays} zile`;
  if (diffDays === -1) return "ieri";
  return `intarziat cu ${Math.abs(diffDays)} zile`;
}

export function getEventChipStyle(item: CalendarItem) {
  const typeCfg = TYPE_CONFIG[item.type];
  const bg = item.customColor || typeCfg.bg;
  const border = item.customColor ? item.customColor : typeCfg.border;

  return {
    background: bg,
    border: `1px solid ${border}`,
    color: typeCfg.color,
    opacity: item.completed ? 0.46 : 1,
    textDecoration: item.completed ? "line-through" : "none",
  };
}

export function groupItemsByDay(items: CalendarItem[], daysInMonth: number) {
  const map = new Map<number, CalendarItem[]>();

  for (let day = 1; day <= daysInMonth; day++) {
    map.set(day, []);
  }

  items.forEach((item) => {
    const day = Number(item.date.split("-")[2]);
    map.get(day)?.push(item);
  });

  for (const [day, dayItems] of map.entries()) {
    dayItems.sort((a, b) => {
      if (a.allDay && !b.allDay) return -1;
      if (!a.allDay && b.allDay) return 1;
      if (!a.time) return -1;
      if (!b.time) return 1;
      return a.time.localeCompare(b.time);
    });
    map.set(day, dayItems);
  }

  return map;
}

export function getTotals(items: CalendarItem[]) {
  const pays = items.filter((i) => i.type === "pay");
  const paid = pays
    .filter((i) => i.completed)
    .reduce((sum, i) => sum + (i.actualPaidAmount ?? i.amount ?? 0), 0);

  const remaining = pays
    .filter((i) => !i.completed)
    .reduce((sum, i) => sum + (i.amount ?? 0), 0);

  return { paid, remaining };
}

export function getMonthName(months: string[], monthIndex: number) {
  return months[monthIndex];
}

export function getTypeLabel(type: EventType) {
  return TYPE_CONFIG[type].label;
}

export function getRepeatLabel(item: CalendarItem) {
  if (item.repeat !== "custom") return item.repeat;

  const every = item.repeatCustomInterval || 1;
  const unit = item.repeatCustomUnit || "day";
  return `every ${every} ${unit}${every > 1 ? "s" : ""}`;
}

export function safeAmount(value: string) {
  const num = Number(value);
  return Number.isFinite(num) ? num : 0;
}

export function getTypeConfig(type: EventType): TypeConfig {
  return TYPE_CONFIG[type];
}