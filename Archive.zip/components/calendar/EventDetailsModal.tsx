"use client";

import { CalendarItem } from "./types";
import { formatEventDateTime, TYPE_CONFIG } from "./utils";

type Props = {
  item: CalendarItem | null;
  onClose: () => void;
  onToggleComplete: (id: string) => void;
  onDelete: (id: string) => void;
  onEdit: (item: CalendarItem) => void;
};

function SectionTitle({ children }: { children: React.ReactNode }) {
  return (
    <div
      style={{
        fontSize: 12,
        textTransform: "uppercase",
        letterSpacing: 1.1,
        opacity: 0.55,
        marginBottom: 6,
      }}
    >
      {children}
    </div>
  );
}

export default function EventDetailsModal({
  item,
  onClose,
  onToggleComplete,
  onDelete,
  onEdit,
}: Props) {
  if (!item) return null;

  const cfg = TYPE_CONFIG[item.type];

  return (
    <div
      onClick={onClose}
      style={{
        position: "fixed",
        inset: 0,
        background: "rgba(0,0,0,0.58)",
        backdropFilter: "blur(12px)",
        display: "flex",
        alignItems: "flex-end",
        justifyContent: "center",
        zIndex: 40,
        padding: 0,
      }}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        style={{
          width: "100%",
          maxWidth: 900,
          maxHeight: "94vh",
          overflowY: "auto",
          background: "#111218",
          borderTopLeftRadius: 28,
          borderTopRightRadius: 28,
          border: "1px solid rgba(255,255,255,0.08)",
          boxShadow: "0 -20px 60px rgba(0,0,0,0.45)",
          animation: "slideUpSheet 180ms ease-out",
        }}
      >
        <style>{`
          @keyframes slideUpSheet {
            from { transform: translateY(28px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
          }
        `}</style>

        <div
          style={{
            position: "sticky",
            top: 0,
            background: "#111218",
            borderBottom: "1px solid rgba(255,255,255,0.06)",
            padding: "14px 16px 12px",
            zIndex: 2,
          }}
        >
          <div
            style={{
              width: 46,
              height: 5,
              borderRadius: 999,
              background: "rgba(255,255,255,0.18)",
              margin: "0 auto 12px",
            }}
          />

          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              gap: 12,
              alignItems: "flex-start",
            }}
          >
            <div>
              <div
                style={{
                  fontSize: 32,
                  fontWeight: 700,
                  lineHeight: 1.06,
                  textDecoration: item.completed ? "line-through" : "none",
                  opacity: item.completed ? 0.5 : 1,
                }}
              >
                {item.title}
              </div>

              <div
                style={{
                  marginTop: 10,
                  display: "inline-flex",
                  alignItems: "center",
                  gap: 8,
                  padding: "8px 12px",
                  borderRadius: 999,
                  background: cfg.bg,
                  border: `1px solid ${cfg.border}`,
                  color: cfg.color,
                  fontSize: 13,
                  fontWeight: 600,
                }}
              >
                <span>{cfg.icon}</span>
                <span>{cfg.label}</span>
              </div>
            </div>

            <button
              onClick={onClose}
              style={{
                border: "none",
                background: "rgba(255,255,255,0.06)",
                color: "white",
                borderRadius: 12,
                padding: "10px 12px",
                cursor: "pointer",
                flexShrink: 0,
              }}
            >
              ✕
            </button>
          </div>
        </div>

        <div style={{ padding: 18, display: "grid", gap: 16 }}>
          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))",
              gap: 14,
            }}
          >
            <div
              style={{
                background: "rgba(255,255,255,0.04)",
                border: "1px solid rgba(255,255,255,0.08)",
                borderRadius: 18,
                padding: 14,
              }}
            >
              <SectionTitle>Data</SectionTitle>
              <div style={{ fontSize: 15 }}>{formatEventDateTime(item)}</div>
            </div>

            <div
              style={{
                background: "rgba(255,255,255,0.04)",
                border: "1px solid rgba(255,255,255,0.08)",
                borderRadius: 18,
                padding: 14,
              }}
            >
              <SectionTitle>Status</SectionTitle>
              <div style={{ fontSize: 15 }}>{item.completed ? "Completed" : "Pending"}</div>
            </div>

            <div
              style={{
                background: "rgba(255,255,255,0.04)",
                border: "1px solid rgba(255,255,255,0.08)",
                borderRadius: 18,
                padding: 14,
              }}
            >
              <SectionTitle>Repeat</SectionTitle>
              <div style={{ fontSize: 15 }}>{item.repeat.label}</div>
            </div>

            <div
              style={{
                background: "rgba(255,255,255,0.04)",
                border: "1px solid rgba(255,255,255,0.08)",
                borderRadius: 18,
                padding: 14,
              }}
            >
              <SectionTitle>All day</SectionTitle>
              <div style={{ fontSize: 15 }}>{item.allDay ? "Da" : "Nu"}</div>
            </div>

            {typeof item.amount === "number" && (
              <div
                style={{
                  background: "rgba(255,255,255,0.04)",
                  border: "1px solid rgba(255,255,255,0.08)",
                  borderRadius: 18,
                  padding: 14,
                }}
              >
                <SectionTitle>Suma</SectionTitle>
                <div style={{ fontSize: 15 }}>{item.amount} lei</div>
              </div>
            )}

            {item.address && (
              <div
                style={{
                  background: "rgba(255,255,255,0.04)",
                  border: "1px solid rgba(255,255,255,0.08)",
                  borderRadius: 18,
                  padding: 14,
                }}
              >
                <SectionTitle>Adresa</SectionTitle>
                <div style={{ fontSize: 15 }}>{item.address}</div>
              </div>
            )}
          </div>

          {item.details && (
            <div
              style={{
                background: "rgba(255,255,255,0.04)",
                border: "1px solid rgba(255,255,255,0.08)",
                borderRadius: 18,
                padding: 16,
              }}
            >
              <SectionTitle>Detalii</SectionTitle>
              <div style={{ fontSize: 15, lineHeight: 1.55, opacity: 0.88 }}>
                {item.details}
              </div>
            </div>
          )}

          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))",
              gap: 10,
            }}
          >
            <button
              onClick={() => onToggleComplete(item.id)}
              style={{
                border: "none",
                borderRadius: 14,
                padding: "14px 16px",
                background: item.completed ? "#f59e0b" : "#22c55e",
                color: "#08110b",
                fontWeight: 700,
                cursor: "pointer",
              }}
            >
              {item.completed ? "Mark pending" : "Mark completed"}
            </button>

            <button
              onClick={() => onEdit(item)}
              style={{
                border: "1px solid rgba(255,255,255,0.08)",
                borderRadius: 14,
                padding: "14px 16px",
                background: "rgba(255,255,255,0.05)",
                color: "white",
                fontWeight: 700,
                cursor: "pointer",
              }}
            >
              Edit
            </button>

            <button
              onClick={() => onDelete(item.id)}
              style={{
                border: "1px solid rgba(239,68,68,0.35)",
                borderRadius: 14,
                padding: "14px 16px",
                background: "rgba(239,68,68,0.16)",
                color: "white",
                fontWeight: 700,
                cursor: "pointer",
              }}
            >
              Delete
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}