"use client";

import { useMemo, useState } from "react";
import AddEventDrawer from "@/components/calendar/AddEventDrawer";
import CalendarFilters from "@/components/calendar/CalendarFilters";
import CalendarGrid from "@/components/calendar/CalendarGrid";
import CalendarHeader from "@/components/calendar/CalendarHeader";
import CalendarList from "@/components/calendar/CalendarList";
import CalendarStats from "@/components/calendar/CalendarStats";
import ColorPickerModal from "@/components/calendar/ColorPickerModal";
import EventDetailsModal from "@/components/calendar/EventDetailsModal";
import RepeatModal from "@/components/calendar/RepeatModal";
import { INITIAL_ITEMS } from "@/components/calendar/mockData";
import {
  CalendarItem,
  CustomRepeatConfig,
  DraftState,
  EventType,
  FilterState,
  ViewMode,
} from "@/components/calendar/types";
import {
  createDefaultDraft,
  formatShortDate,
  getDaysInMonth,
  getMonthName,
} from "@/components/calendar/utils";

type Props = {
  version: string;
};

export default function HomeClient({ version }: Props) {
  const today = new Date();
  const [selectedYear, setSelectedYear] = useState(today.getFullYear());
  const [selectedMonth, setSelectedMonth] = useState(today.getMonth());
  const [viewMode, setViewMode] = useState<ViewMode>("grid");
  const [items, setItems] = useState<CalendarItem[]>(INITIAL_ITEMS);
  const [selectedItem, setSelectedItem] = useState<CalendarItem | null>(null);
  const [showAddDrawer, setShowAddDrawer] = useState(false);
  const [showRepeatModal, setShowRepeatModal] = useState(false);
  const [showColorModal, setShowColorModal] = useState(false);
  const [hideEmptyDays, setHideEmptyDays] = useState(false);

  const [activeFilters, setActiveFilters] = useState<FilterState>({
    task: true,
    event: true,
    pay: true,
    birthday: true,
  });

  const [draft, setDraft] = useState<DraftState>(
    createDefaultDraft(selectedYear, selectedMonth)
  );

  const daysInMonth = useMemo(
    () => getDaysInMonth(selectedYear, selectedMonth),
    [selectedYear, selectedMonth]
  );

  const monthItems = useMemo(() => {
    return items.filter((item) => {
      const [y, m] = item.date.split("-").map(Number);
      return (
        y === selectedYear &&
        m === selectedMonth + 1 &&
        activeFilters[item.type]
      );
    });
  }, [items, selectedYear, selectedMonth, activeFilters]);

  const groupedByDay = useMemo(() => {
    const map = new Map<number, CalendarItem[]>();

    for (let day = 1; day <= daysInMonth; day++) {
      map.set(day, []);
    }

    monthItems.forEach((item) => {
      const day = Number(item.date.split("-")[2]);
      map.get(day)?.push(item);
    });

    for (const [day, dayItems] of map.entries()) {
      dayItems.sort((a, b) => {
        if (a.allDay && !b.allDay) return -1;
        if (!a.allDay && b.allDay) return 1;
        if (!a.time) return -1;
        if (!b.time) return 1;
        return (a.time || "").localeCompare(b.time || "");
      });
      map.set(day, dayItems);
    }

    return map;
  }, [monthItems, daysInMonth]);

  const totals = useMemo(() => {
    const pays = monthItems.filter((i) => i.type === "pay");
    const paid = pays
      .filter((i) => i.completed)
      .reduce((sum, i) => sum + (i.amount || 0), 0);
    const remaining = pays
      .filter((i) => !i.completed)
      .reduce((sum, i) => sum + (i.amount || 0), 0);

    return { paid, remaining };
  }, [monthItems]);

  const years = Array.from({ length: 9 }, (_, index) => today.getFullYear() - 3 + index);

  const tomorrowPreview = useMemo(() => {
    const tomorrow = new Date();
    tomorrow.setDate(today.getDate() + 1);
    return `Reminderul WhatsApp se trimite cu o zi inainte, seara, in jurul orei 22:00 pentru evenimentele din ${formatShortDate(tomorrow.toISOString())}.`;
  }, [today]);

  function openCreateDrawer() {
    setDraft(createDefaultDraft(selectedYear, selectedMonth));
    setShowAddDrawer(true);
  }

  function toggleFilter(type: EventType) {
    setActiveFilters((prev) => ({
      ...prev,
      [type]: !prev[type],
    }));
  }

  function updateDraft(patch: Partial<DraftState>) {
    setDraft((prev) => ({ ...prev, ...patch }));
  }

  function createMockEvent() {
    if (!draft.title.trim()) return;

    const newItem: CalendarItem = {
      id: crypto.randomUUID(),
      title: draft.title.trim(),
      details: draft.details.trim() || undefined,
      type: draft.type,
      date: draft.date,
      time: draft.allDay ? undefined : draft.time,
      allDay: draft.allDay,
      completed: false,
      repeat: draft.repeat,
      amount:
        draft.type === "pay" || draft.amount.trim()
          ? Number(draft.amount || 0)
          : undefined,
      address: draft.address.trim() || undefined,
      customColor: draft.customColor.trim() || undefined,
    };

    setItems((prev) => [...prev, newItem]);
    setShowAddDrawer(false);
  }

  function toggleComplete(itemId: string) {
    setItems((prev) =>
      prev.map((item) =>
        item.id === itemId ? { ...item, completed: !item.completed } : item
      )
    );

    setSelectedItem((prev) =>
      prev && prev.id === itemId ? { ...prev, completed: !prev.completed } : prev
    );
  }

  function deleteItem(itemId: string) {
    setItems((prev) => prev.filter((item) => item.id !== itemId));
    if (selectedItem?.id === itemId) {
      setSelectedItem(null);
    }
  }

  function startEdit(item: CalendarItem) {
    setDraft({
      title: item.title,
      details: item.details || "",
      type: item.type,
      date: item.date,
      time: item.time || "10:00",
      allDay: item.allDay,
      repeat: item.repeat,
      amount: typeof item.amount === "number" ? String(item.amount) : "",
      address: item.address || "",
      customColor: item.customColor || "",
    });

    setSelectedItem(null);
    setShowAddDrawer(true);
  }

  function saveCustomRepeat(value: CustomRepeatConfig) {
    let label = `Every ${value.interval} ${value.unit}`;
    if (value.interval > 1) {
      label += "s";
    }
    if (value.unit === "month" && value.monthDay) {
      label += ` on day ${value.monthDay}`;
    }

    setDraft((prev) => ({
      ...prev,
      repeat: {
        value: "custom",
        label,
        custom: value,
      },
    }));
  }

  return (
    <main
      style={{
        minHeight: "100vh",
        background:
          "radial-gradient(circle at top, rgba(90,110,255,0.12), transparent 28%), #09090d",
        color: "white",
        fontFamily: "system-ui, -apple-system, BlinkMacSystemFont, sans-serif",
        paddingBottom: 120,
      }}
    >
      <div
        style={{
          maxWidth: 1440,
          margin: "0 auto",
          padding: "18px 14px 24px",
        }}
      >
        <CalendarHeader
          version={version}
          selectedYear={selectedYear}
          selectedMonth={selectedMonth}
          years={years}
          viewMode={viewMode}
          onYearChange={setSelectedYear}
          onMonthChange={setSelectedMonth}
          onViewModeChange={setViewMode}
        />

        <CalendarStats
          paid={totals.paid}
          remaining={totals.remaining}
          reminderText={tomorrowPreview}
        />

        <CalendarFilters
          activeFilters={activeFilters}
          hideEmptyDays={hideEmptyDays}
          onToggleFilter={toggleFilter}
          onToggleHideEmptyDays={() => setHideEmptyDays((prev) => !prev)}
        />

        {viewMode === "grid" ? (
          <CalendarGrid
            year={selectedYear}
            month={selectedMonth}
            daysInMonth={daysInMonth}
            groupedByDay={groupedByDay}
            onSelectItem={setSelectedItem}
          />
        ) : (
          <CalendarList
            year={selectedYear}
            month={selectedMonth}
            daysInMonth={daysInMonth}
            groupedByDay={groupedByDay}
            hideEmptyDays={hideEmptyDays}
            onSelectItem={setSelectedItem}
          />
        )}

        <button
          onClick={openCreateDrawer}
          style={{
            position: "fixed",
            right: 22,
            bottom: 22,
            width: 68,
            height: 68,
            borderRadius: "50%",
            border: "none",
            background:
              "linear-gradient(180deg, rgba(59,130,246,1), rgba(37,99,235,1))",
            color: "white",
            fontSize: 34,
            cursor: "pointer",
            boxShadow: "0 22px 40px rgba(37,99,235,0.35)",
            zIndex: 20,
          }}
        >
          +
        </button>
      </div>

      <AddEventDrawer
        isOpen={showAddDrawer}
        draft={draft}
        onClose={() => setShowAddDrawer(false)}
        onSave={createMockEvent}
        onChange={updateDraft}
        onOpenRepeatModal={() => setShowRepeatModal(true)}
        onOpenColorModal={() => setShowColorModal(true)}
      />

      <RepeatModal
        isOpen={showRepeatModal}
        value={draft.repeat.custom || { interval: 1, unit: "week", monthDay: 1 }}
        onClose={() => setShowRepeatModal(false)}
        onSave={saveCustomRepeat}
      />

      <ColorPickerModal
        isOpen={showColorModal}
        value={draft.customColor}
        onClose={() => setShowColorModal(false)}
        onSave={(value) => updateDraft({ customColor: value })}
      />

      <EventDetailsModal
        item={selectedItem}
        onClose={() => setSelectedItem(null)}
        onToggleComplete={toggleComplete}
        onDelete={deleteItem}
        onEdit={startEdit}
      />
    </main>
  );
}